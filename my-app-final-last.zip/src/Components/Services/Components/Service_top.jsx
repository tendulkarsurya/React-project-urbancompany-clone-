import React from 'react'

const Service_top = () => {
  return (
    <div className='service_top'>
      <div className='service_bg'>
        <h1>SERVICES</h1>
      </div>
    </div>
  )
}

export default Service_top
