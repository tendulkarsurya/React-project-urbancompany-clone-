import React from 'react'

const About_Top = () => {
    return (
        <div>
            <div className='bg_container'>
                <h1>About us</h1>
            </div>
        </div>
    )
}

export default About_Top
