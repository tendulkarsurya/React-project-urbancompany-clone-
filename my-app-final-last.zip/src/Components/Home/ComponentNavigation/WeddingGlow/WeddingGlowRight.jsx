import React from 'react'

const WeddingGlowRight = () => {
    return (
        <div>
            <div>
                <video src="" controls className='videoAC'>
                    <source src='./Assets/videoframe_AC.mp4' />
                </video>
            </div>
        </div>
    )
}

export default WeddingGlowRight
