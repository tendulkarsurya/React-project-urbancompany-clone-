import React from 'react'

const BRservicingRight = () => {
  return (
    <div>
      <div>
        <video src="./Assets/common.mp4" controls className='videoAC' muted autoPlay >

        </video>
      </div>
    </div>
  )
}

export default BRservicingRight
