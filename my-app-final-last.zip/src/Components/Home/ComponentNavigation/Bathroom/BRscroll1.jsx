import React from 'react'
import BRscroll2Copy from './BRscroll2Copy'

const BRscroll1 = () => {
  return (
    <div id='ACS'>
      <div>
        {/* <h3 className='fw-bold'>Super saver deals</h3> */}

        <div className='scroll1'><video src="./Assets/common.mp4"  controls alt="" /></div>
        <BRscroll2Copy />
      </div>
    </div>
  )
}

export default BRscroll1
