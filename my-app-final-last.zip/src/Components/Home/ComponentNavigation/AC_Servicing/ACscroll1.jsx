import React from 'react'
import '../ACscrolls.css'

const ACscroll1 = () => {
  return (
    <div id='ACS'>
      <div>
        <h3 className='fw-bold'>Service</h3>
        <div className='scroll1'><img src="./Assets/scroll1.jpg" alt="" /></div>
      </div>
    </div>
  )
}

export default ACscroll1
