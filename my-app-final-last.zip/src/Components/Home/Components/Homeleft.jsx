import React from 'react'

import './Homeleft.css'
import Homeservices from './Homeservices'
const Homeleft = () => {
    return (
        <div>
            <div>
                <div>
                    <h2 >Home services at your doorstep</h2>
                </div>
                <Homeservices></Homeservices>
            </div>
        </div>
    )
}

export default Homeleft
