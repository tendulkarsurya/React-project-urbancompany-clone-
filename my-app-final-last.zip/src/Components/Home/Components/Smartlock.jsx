import React from 'react'
import './Rowater.css'
const Smartlock = () => {
  return (
    <div>
      <div className='RowaterDiv' >
        <img className='pt-5' style={{width:"100%"}} src="./Assets/smartlock.jpg" alt="" />
      </div>
    </div>
  )
}

export default Smartlock
