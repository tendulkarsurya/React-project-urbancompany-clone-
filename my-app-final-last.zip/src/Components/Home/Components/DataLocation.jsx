let DataLocation = [
    {
        City: "Chennai",
        logo: "../Assets/chennai.avif"
    },
    {
        City: "Bangalore",
        logo: "../Assets/bangalore.png"
    },
    {
        City: "Hyderabad",
        logo: "../Assets/hyderabad.png"
    },
    {
        City: "Mumbai",
        logo: "../Assets/mumbai.avif"
    },
    {
        City: "Delhi",
        logo: "../Assets/delhi.avif"
    },
    {
        City: "Ahmedabad",
        logo: "../Assets/ahmedabad.avif"
    },
    {
        City: "Kolkata",
        logo: "../Assets/kolkata.avif"
    },
    {
        City: "Pune",
        logo: "../Assets/pune.png"
    },


]




export default DataLocation