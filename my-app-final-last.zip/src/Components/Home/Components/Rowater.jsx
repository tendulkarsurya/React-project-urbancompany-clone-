import React from 'react'
import './Rowater.css'

const Rowater = () => {
    
  return (
    <div>
      <div className='RowaterDiv' >
        <img className='pt-5' style={{width:"100%"}} src="./Assets/ro-water.jpg" alt="" />
   
      </div>
    </div>
  )
}

export default Rowater
